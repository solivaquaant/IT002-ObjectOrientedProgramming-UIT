class PhanSo
{
    private:
    int tuso, mauso;
    public:
    void Nhap();
    void Xuat();
    void RutGon();
};